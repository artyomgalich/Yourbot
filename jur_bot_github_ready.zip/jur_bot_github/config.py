
TOKEN = "your_bot_token_here"
