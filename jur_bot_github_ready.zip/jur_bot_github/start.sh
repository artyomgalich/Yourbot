
#!/bin/bash
echo "Starting bot..."
python3 bot.py
