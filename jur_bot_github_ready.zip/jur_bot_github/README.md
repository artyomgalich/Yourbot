
# Юридичний Telegram-бот 🇺🇦

Цей бот створює юридичні документи у форматі PDF за введеним текстом.

## Команди:
- `/start` — старт бота
- Надішліть будь-який текст — отримаєте PDF-файл

## Встановлення

```bash
pip install -r requirements.txt
python bot.py
```

## Налаштування
У файл `config.py` вставте свій токен Telegram-бота:

```python
TOKEN = "your_bot_token_here"
```
